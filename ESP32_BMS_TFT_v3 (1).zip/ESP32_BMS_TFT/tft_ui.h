/*
 * tft_ui.h  -  3.5인치 TFT(320x480, SPI) 현장 대시보드
 * ----------------------------------------------------------
 * 라이브러리: LovyanGFX (Library Manager에서 "LovyanGFX" 검색 후 설치)
 * 연결(config.h): SCL=GPIO18, SDA=GPIO23, CS=GPIO17, DC=GPIO16, RST=GPIO19,
 *                 VCC=3V3, GND=GND, BL=3V3(항상 켜짐), SDO=연결 안 함
 * 화면: 가로(480x320) - 위: 상태 배너, 가운데: 수치 4칸, 아래: 전류·온도 2분 추이 그래프
 */
#pragma once
#include <LovyanGFX.hpp>
#include "config.h"

// ---------------- 패널 설정 ----------------
class LGFX : public lgfx::LGFX_Device {
#if TFT_DRIVER_ST7796
  lgfx::Panel_ST7796 _panel;
#else
  lgfx::Panel_ILI9488 _panel;
#endif
  lgfx::Bus_SPI _bus;
public:
  LGFX() {
    {
      auto cfg = _bus.config();
      cfg.spi_host   = SPI3_HOST;        // ESP32의 VSPI
      cfg.spi_mode   = 0;
      cfg.freq_write = TFT_SPI_HZ;       // 수정됨: config.h에서 설정 (긴 점퍼선이면 10MHz)
      cfg.freq_read  = 16000000;
      cfg.spi_3wire  = false;
      cfg.use_lock   = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      cfg.pin_sclk = PIN_TFT_SCLK;
      cfg.pin_mosi = PIN_TFT_MOSI;
      cfg.pin_miso = -1;                 // SDO는 쓰지 않음
      cfg.pin_dc   = PIN_TFT_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs   = PIN_TFT_CS;
      cfg.pin_rst  = PIN_TFT_RST;
      cfg.pin_busy = -1;
      cfg.panel_width  = 320;
      cfg.panel_height = 480;
      cfg.offset_x = 0;
      cfg.offset_y = 0;
      cfg.offset_rotation = 0;
      cfg.readable   = false;
      cfg.invert     = TFT_INVERT;       // 색이 반전돼 보이면 config.h에서 1
      cfg.rgb_order  = TFT_BGR;          // 빨강·파랑이 바뀌면 config.h에서 1
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel.config(cfg);
    }
    setPanel(&_panel);
  }
};

// ---------------- 화면 그리기 ----------------
namespace ui {

LGFX tft;
LGFX_Sprite chart(&tft);        // 그래프 깜빡임 방지용 버퍼 (없으면 직접 그림)
bool chartOk = false;

const int HIST = 120;           // 2분(1초 1점)
float histI[HIST], histT[HIST];
int histN = 0, histHead = 0;

// 단계별 색 (정상·주의·경고·위험)
const uint32_t LV_COLOR[4] = { 0x1E9E55u, 0xE6B800u, 0xF07F12u, 0xD62F2Fu };
const char* LV_TEXT[4] = { "NORMAL", "CAUTION", "WARNING", "DANGER" };
const uint32_t BG = 0x101418u, PANEL = 0x1C2329u, INK = 0xE9EEF0u, SOFT = 0x8FA0A8u, GRID = 0x2E3940u;

void begin() {
  tft.init();
  tft.setRotation(1);             // 가로 480x320
  tft.fillScreen(BG);
  chartOk = chart.createSprite(232, 128) != nullptr;
}

// 부팅 화면: Wi-Fi 접속 정보
void bootScreen(const String& ssid, const char* pw) {
  tft.fillScreen(BG);
  tft.setTextColor(INK, BG);
  tft.setFont(&fonts::FreeSansBold18pt7b);
  tft.drawString("ESP32 BMS", 24, 30);
  tft.setFont(&fonts::FreeSans12pt7b);
  tft.setTextColor(SOFT, BG);
  tft.drawString("USB 5V monitor  (no battery)", 24, 80);
  tft.setTextColor(INK, BG);
  tft.drawString("WiFi : " + ssid, 24, 140);
  tft.drawString(String("PW   : ") + pw, 24, 175);
  tft.drawString("http://192.168.4.1", 24, 210);
  tft.setTextColor(SOFT, BG);
  tft.drawString("Booting...   FW " FW_VERSION, 24, 270);   // 수정됨
}

void pushHistory(float i, float t) {
  histI[histHead] = i;
  histT[histHead] = t;
  histHead = (histHead + 1) % HIST;
  if (histN < HIST) histN++;
}

// 수치 칸 하나
void tile(int x, int y, const char* label, const String& value, const char* unit, uint32_t col) {
  const int w = 112, h = 92;
  tft.fillRoundRect(x, y, w, h, 8, PANEL);
  tft.setTextColor(SOFT, PANEL);
  tft.setFont(&fonts::FreeSans9pt7b);
  tft.drawString(label, x + 10, y + 8);
  tft.setTextColor(col, PANEL);
  tft.setFont(&fonts::FreeSansBold18pt7b);
  tft.drawString(value, x + 10, y + 34);
  tft.setTextColor(SOFT, PANEL);
  tft.setFont(&fonts::FreeSans9pt7b);
  tft.drawString(unit, x + 10, y + 70);
}

// 추이 그래프 하나 (스프라이트에 그린 뒤 한 번에 전송)
template <typename G>
void drawChart(G& g, int ox, int oy, const char* title, float* data, float vmin, float vmax, float warnLine, uint32_t col) {
  const int w = 232, h = 128, px = 34, py = 22, pw = w - px - 8, ph = h - py - 14;
  g.fillRect(ox, oy, w, h, PANEL);
  g.setTextColor(INK, PANEL);
  g.setFont(&fonts::FreeSans9pt7b);
  g.drawString(title, ox + 8, oy + 4);
  g.setFont(&fonts::Font0);
  g.setTextColor(SOFT, PANEL);
  for (int k = 0; k <= 2; k++) {
    float v = vmin + (vmax - vmin) * k / 2;
    int y = oy + py + ph - (int)(ph * k / 2);
    g.drawFastHLine(ox + px, y, pw, GRID);
    g.drawString(String((int)v), ox + 6, y - 4);
  }
  int wy = oy + py + ph - (int)(ph * (warnLine - vmin) / (vmax - vmin));
  for (int x = 0; x < pw; x += 6) g.drawFastHLine(ox + px + x, wy, 3, 0xF07F12u);
  if (histN > 1) {
    int prevX = -1, prevY = -1;
    for (int k = 0; k < histN; k++) {
      int idx = (histHead - histN + k + HIST) % HIST;
      float v = data[idx];
      if (isnan(v)) { prevX = -1; continue; }
      if (v < vmin) v = vmin; if (v > vmax) v = vmax;
      int x = ox + px + (int)((long)pw * (HIST - histN + k) / (HIST - 1));
      int y = oy + py + ph - (int)(ph * (v - vmin) / (vmax - vmin));
      if (prevX >= 0) { g.drawLine(prevX, prevY, x, y, col); g.drawLine(prevX, prevY + 1, x, y + 1, col); }
      prevX = x; prevY = y;
    }
  }
  g.drawString("-2 min", ox + px, oy + h - 10);
  g.drawString("now", ox + w - 26, oy + h - 10);
}

void chartAt(int x, int y, const char* title, float* data, float vmin, float vmax, float warnLine, uint32_t col) {
  if (chartOk) {
    drawChart(chart, 0, 0, title, data, vmin, vmax, warnLine, col);
    chart.pushSprite(x, y);
  } else {
    drawChart(tft, x, y, title, data, vmin, vmax, warnLine, col);
  }
}

// 1초마다 전체 갱신
void update(float vbus, float mA, bool tOk, float tC, float dTdt, float risk, float minsToDanger,
            int level, bool latched, bool loadOn, const String& reason) {
  // 수정됨: 첫 갱신 때 부팅 화면 글자를 지움 (글자가 겹쳐 보이던 문제)
  static bool firstDraw = true;
  if (firstDraw) { tft.fillScreen(BG); firstDraw = false; }

  // (1) 상태 배너
  uint32_t lc = (latched && level < 3) ? 0x2563C9u : LV_COLOR[level];
  tft.fillRect(0, 0, 480, 44, lc);
  tft.setTextColor(0xFFFFFFu, lc);
  tft.setFont(&fonts::FreeSansBold18pt7b);
  tft.drawString(latched ? "TRIP - press reset" : LV_TEXT[level], 12, 8);
  tft.setFont(&fonts::FreeSansBold12pt7b);
  tft.setTextDatum(textdatum_t::top_right);
  tft.drawString(loadOn ? "LOAD ON" : "LOAD OFF", 468, 12);
  tft.setTextDatum(textdatum_t::top_left);

  // (2) 수치 4칸
  tile(8,   52, "VBUS",    String(vbus, 2), "V",  INK);
  tile(128, 52, "CURRENT", String(mA, 1),   "mA", INK);
  tile(248, 52, "TEMP",    tOk ? String(tC, 1) : String("ERR"), "C", tOk ? INK : LV_COLOR[2]);
  tile(368, 52, "RISK",    String((int)risk), "/100", risk >= 70 ? LV_COLOR[3] : risk >= 50 ? LV_COLOR[2] : risk >= 30 ? LV_COLOR[1] : INK);

  // (3) 한 줄 요약: 온도 상승률, 위험온도 도달 예측, 판정 사유
  tft.fillRect(0, 148, 480, 26, BG);
  tft.setFont(&fonts::FreeSans9pt7b);
  tft.setTextColor(SOFT, BG);
  String line = "dT/dt " + String(dTdt, 1) + " C/min   ";
  line += (minsToDanger > 0) ? ("45C in " + String(minsToDanger, 1) + " min   ") : String("45C in --   ");
  line += reason;
  if (line.length() > 60) line = line.substring(0, 60);
  tft.drawString(line, 10, 152);

  // (4) 2분 추이 그래프 (전류, 온도)
  pushHistory(mA, tOk ? tC : NAN);
  chartAt(8,   184, "Current (mA)", histI, 0, 40, OC_DANGER, 0x5FB3FFu);
  chartAt(240, 184, "Temp (C)",     histT, 20, 50, OT_DANGER, 0xFFB347u);
}

}  // namespace ui
