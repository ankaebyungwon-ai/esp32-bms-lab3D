/*
 * config.h  -  ESP32 교육용 BMS (모의 셀 버전) 설정 파일
 * ----------------------------------------------------------
 * 배터리 셀 없이 '모의 셀(가변저항 전압원)'과 'USB 5V 부하 회로'로 실습하는 버전입니다.
 * 핀 번호, 임계값(Threshold), 필터 상수, Wi-Fi 정보를 한곳에 모았습니다.
 * 실습 중 값을 바꿀 때는 이 파일만 수정하면 됩니다.
 */
#pragma once

#define FW_VERSION "v3 (10k/10k, shunt 110R)"   // 수정됨: 올린 펌웨어가 맞는지 부팅 화면·시리얼로 확인

// ======================= 1. 3.5인치 TFT (320x480, SPI) =======================  // 수정됨
// 화면이 안 나오면 TFT_DRIVER_ST7796을 0으로(ILI9488) 바꿔 다시 올려 보세요.
#define TFT_DRIVER_ST7796  1   // 1: ST7796S, 0: ILI9488
#define TFT_INVERT         0   // 색이 반전돼(검정↔흰색) 보이면 1
#define TFT_BGR            0   // 빨강과 파랑이 바뀌어 보이면 1
#define TFT_SPI_HZ  10000000   // SPI 속도. 점퍼선이 길면 10MHz가 안정적 (짧으면 40000000까지)

// ======================= 2. 핀 배치 (ESP32 DevKitC V4) =======================
// ※ Wi-Fi 사용 중에는 ADC2 핀을 쓸 수 없으므로 아날로그 입력은 모두 ADC1(GPIO32~39)을 사용
#define PIN_VBAT      34   // 모의 셀 전압 → 전압 분배기 → 입력 (ADC1_CH6, 입력 전용 핀)
#define PIN_ISHUNT    35   // 션트저항 전압 입력                 (ADC1_CH7, 입력 전용 핀)
#define PIN_DS18B20    4   // 디지털 온도센서(DS18B20) 데이터
#define PIN_RELAY     26   // 방전(부하) 차단 릴레이
#define PIN_BUZZER    25   // 부저
#define PIN_LED_R     27   // RGB LED - 빨강
#define PIN_LED_G     14   // RGB LED - 초록
#define PIN_LED_B     33   // RGB LED - 파랑
#define PIN_BUTTON    13   // 푸시버튼 (반대쪽 다리는 GND, 내부 풀업 사용)

// 3.5인치 TFT (SPI)  // 수정됨: LCD 2004 핀 대신
#define PIN_TFT_SCLK  18   // TFT SCL
#define PIN_TFT_MOSI  23   // TFT SDA
#define PIN_TFT_CS    17   // TFT CS
#define PIN_TFT_DC    16   // TFT DC
#define PIN_TFT_RST   19   // TFT RST
// TFT VCC·BL → 3V3, GND → GND, SDO → 연결 안 함

#define RELAY_ON_LEVEL   HIGH   // 릴레이 모듈이 LOW에서 동작하면 LOW로 변경
#define LED_COMMON_ANODE 0      // 공통 양극(+) RGB LED면 1

// ======================= 3. 측정 회로 상수 =======================
// 모의 셀 : 5V - Ra(1kΩ) - 가변저항(10kΩ) - Rb(10kΩ) - GND,  와이퍼 전압 약 2.4 ~ 4.8 V
#define VDIV_R_TOP      10000.0f  // 전압 분배 위쪽 저항 R1 [옴]  (5V 레일 쪽)  // 수정됨: 키트에 있는 10kΩ 사용
#define V_NOMINAL      4.75f      // 정상 전원 전압 [V] (위험도 지수 기준)  // 수정됨
#define VDIV_R_BOTTOM   10000.0f  // 전압 분배 아래쪽 저항 R2 [옴] (GND 쪽)  // 수정됨: 10kΩ
// 부하 : USB 5V - 릴레이 - 부하(330Ω, +220Ω, +220Ω 병렬) - 션트(220Ω 2개 병렬 = 110Ω) - GND  // 수정됨: 10Ω 없음
#define SHUNT_OHM         110.0f  // 션트 저항 [옴]  // 수정됨

// ======================= 4. 필터 / 주기 =======================
#define SAMPLE_PERIOD_MS   100    // ADC 샘플링 주기 (10 Hz)
#define REPORT_PERIOD_MS  1000    // 진단/TFT/기록 주기 (1 Hz)
#define ADC_OVERSAMPLE      16    // 1회 측정 시 평균낼 ADC 읽기 횟수
#define MA_WINDOW           10    // 이동평균 창 크기 (10샘플 = 1초)
#define EMA_ALPHA         0.20f   // 지수이동평균 계수 (0~1, 작을수록 부드러움)
#define SLOPE_WINDOW_S      30    // 변화율(dV/dt, dT/dt) 계산 구간 [초]

// ======================= 5. 4단계 판정 임계값 =======================
// 각 항목은 {주의, 경고, 위험} 순서. 전압은 실제 리튬이온 셀 기준값을 그대로 사용
// 과전압 [V]  - 배터리 없이 USB 5V 전원 전압을 감시 (수정됨)
#define OV_CAUTION   5.25f   // 수정됨: USB 5V 전원 감시용
#define OV_WARNING   5.40f   // 수정됨
#define OV_DANGER    5.60f   // 수정됨
// 저전압 [V]
#define UV_CAUTION   4.40f   // 수정됨: USB 5V가 ESP32 보호 다이오드를 지나 4.5~4.8V로 떨어지는 것을 반영
#define UV_WARNING   4.20f   // 수정됨
#define UV_DANGER    4.00f   // 수정됨
// 과전류(방전) [mA]  - 부하별 예상 전류: 330Ω만 11.4, +220Ω 20.7, +220Ω 26.0 mA  // 수정됨
#define OC_CAUTION   15.0f
#define OC_WARNING   18.0f
#define OC_DANGER    23.5f
// 과열 [°C]  - 손 체온·미지근한 물로 실습할 수 있도록 낮춘 교육용 값
#define OT_CAUTION   32.0f
#define OT_WARNING   38.0f
#define OT_DANGER    45.0f
// 온도 상승률 [°C/min]  (열폭주 전조)
#define DTDT_CAUTION  1.0f
#define DTDT_WARNING  3.0f
#define DTDT_DANGER   6.0f
// 열폭주 예측: 현재 상승률로 위험온도까지 도달 예상시간이 이 값보다 짧으면 '경고'
#define PREDICT_WARN_MIN 5.0f

// 위험도 지수(Risk Index) 가중치 (합 = 1.0)  - AHP 등으로 정해 바꿔볼 수 있음
#define W_VOLT   0.25f
#define W_TEMP   0.35f
#define W_DVDT   0.15f
#define W_DTDT   0.25f
// 위험도 지수 → 단계 경계 (0~100)
#define RISK_CAUTION 30.0f
#define RISK_WARNING 50.0f
#define RISK_DANGER  70.0f

// ======================= 6. Wi-Fi (AP 모드) =======================
// ESP32가 직접 공유기(AP)가 됩니다. 스마트폰/PC로 이 Wi-Fi에 접속 후
// 브라우저에서 http://192.168.4.1 로 접속하면 대시보드가 열립니다.
#define WIFI_SSID_PREFIX "BMS-"      // 실제 SSID = BMS-<보드 고유번호 4자리>
#define WIFI_PASSWORD    "12345678"  // 8자 이상

// ======================= 7. 데이터 버퍼 (FIFO) =======================
#define LOG_BUFFER_SIZE 600   // 1초 1건 → 10분 분량을 SRAM에 보관
#define EVENT_BUFFER_SIZE 30  // 이상 발생 이력 보관 개수
