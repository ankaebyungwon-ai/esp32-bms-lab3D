/*
 * ESP32_BMS_TFT.ino  -  ESP32 기반 교육용 BMS (USB 5V 전원 감시 + 3.5인치 TFT 버전)
 *  수정됨: GPIO34는 5V 레일을 10k/10k로 나눈 전압을 읽음. '// 수정됨' 주석이 바뀐 곳
 * ---------------------------------------------------------------------------
 *  보드      : ESP32 Dev Module (ESP32 DevKitC V4, ESP32-WROOM-32E)
 *  필요 라이브러리 : OneWire (Paul Stoffregen)
 *                   LovyanGFX (lovyan03)      ※ 3.5인치 TFT  // 수정됨
 *  PC 프로그램 없이 아두이노 IDE(시리얼 모니터 / 시리얼 플로터)와 웹 브라우저만 사용합니다.
 *
 *  배터리 대신 사용하는 것
 *   - 모의 셀 전압 : 5V - 1kΩ - 가변저항 10kΩ - 10kΩ - GND 의 와이퍼 (약 2.4 ~ 4.8 V)
 *   - 방전 부하    : USB 5V - 릴레이 - 330Ω(+220Ω+220Ω 병렬) - 션트 220Ω×2 병렬(110Ω) - GND
 *   - 셀 온도      : DS18B20 센서를 손·미지근한 물로 데움
 *
 *  기능
 *   1) 측정   : 모의 셀 전압(전압분배), 부하 전류(션트저항), 온도(DS18B20)
 *   2) 필터   : 오버샘플링 → 이동평균(MA) → 지수이동평균(EMA)
 *   3) 진단   : 과전압/저전압/과전류/과열/온도상승률 4단계(정상·주의·경고·위험) 판정
 *              + 위험도 지수(Risk Index) + 열폭주 도달시간 예측
 *   4) 보호   : '위험' 판정 시 릴레이로 부하 차단(래치), 부저·RGB LED 경보
 *   5) 표시   : 3.5인치 TFT 대시보드, 시리얼 모니터(CSV), 시리얼 플로터(그래프), Wi-Fi 웹 대시보드
 *   6) 무결성 : SRAM 링버퍼(FIFO)에 기록 → 통신 끊김 후 재접속 시 미전송 데이터 일괄 전송
 *   7) SOC    : 개방전압(OCV) 테이블, 부하 전류 적산(mAh)
 */
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <OneWire.h>
#include "config.h"
#include "dashboard.h"

#include "tft_ui.h"            // 수정됨: LCD 2004 대신 3.5인치 TFT (LovyanGFX)

// ============================================================================
//  자료형 / 전역 변수
// ============================================================================
enum Level : uint8_t { NORMAL = 0, CAUTION = 1, WARNING = 2, DANGER = 3 };
const char* LEVEL_EN[] = { "NORMAL ", "CAUTION", "WARNING", "DANGER " };

// 시리얼 출력 모드 : CSV(시리얼 모니터용) / 그래프(시리얼 플로터용)
enum PlotMode : uint8_t { PLOT_OFF = 0, PLOT_V, PLOT_I, PLOT_T };
const char* PLOT_NAME[] = { "off(CSV)", "voltage", "current", "temperature" };

struct Record {            // 1초마다 저장되는 측정 기록 (FIFO 버퍼 1칸)
  uint32_t seq;            // 일련번호 (1부터 증가) - 누락 확인용
  uint32_t ms;             // 부팅 후 경과시간 [ms]
  float v, i, t, soc, risk;
  uint8_t level, load;
};

struct Event {             // 이상 발생 이력
  uint32_t seq;
  uint32_t ms;
  uint8_t level;
  char msg[64];
};

// --- FIFO(링버퍼) ---
Record   logBuf[LOG_BUFFER_SIZE];
uint32_t logNextSeq = 1;   // 다음에 기록할 일련번호
Event    evBuf[EVENT_BUFFER_SIZE];
uint32_t evNextSeq = 1;

// --- 측정값 ---
float maV[MA_WINDOW], maI[MA_WINDOW];   // 이동평균 창
int   maIdx = 0, maCount = 0;
float vRawLast = 0, iRawLast = 0;       // 필터 전 값 (플로터 비교용)
float vFilt = 0, iFilt = 0;             // 이동평균 결과
float vEma = NAN, tEma = NAN;           // 지수이동평균 (변화율 계산용)
float tempC = NAN;                      // 온도
float histV[SLOPE_WINDOW_S + 1], histT[SLOPE_WINDOW_S + 1];  // 변화율용 1초 이력
int   histIdx = 0, histCount = 0;
float dVdt = 0, dTdt = 0;               // [V/min], [°C/min]
float socPct = 0, mAhOut = 0, riskIdx = 0, minsToDanger = -1;

// --- 상태 ---
Level    level = NORMAL, prevLevel = NORMAL;
bool     loadOn = false;     // 방전 릴레이 상태
bool     latched = false;    // '위험'으로 차단된 상태(수동 리셋 필요)
bool     tempOk = false;
PlotMode plotMode = PLOT_OFF;
String   reasonStr = "";     // 현재 판정 사유
float    vCal = 1.0f;        // 전압 보정계수 (cal 명령으로 저장)

// --- 주변장치 ---
OneWire    ds(PIN_DS18B20);
uint8_t    dsAddr[8];
bool       dsFound = false, dsConverting = false;
WebServer  server(80);
Preferences prefs;
String     apSsid;

uint32_t tSample = 0, tReport = 0;

// ============================================================================
//  유틸리티
// ============================================================================
float clamp01(float x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
Level maxLv(Level a, Level b) { return a > b ? a : b; }

// 같은 핀을 여러 번 읽어 평균 (ESP32 ADC 잡음 감소 = 오버샘플링)
float readMilliVolts(int pin) {
  uint32_t sum = 0;
  for (int k = 0; k < ADC_OVERSAMPLE; k++) sum += analogReadMilliVolts(pin);
  return (float)sum / ADC_OVERSAMPLE;
}

void setRgb(bool r, bool g, bool b) {
  digitalWrite(PIN_LED_R, r ^ LED_COMMON_ANODE);
  digitalWrite(PIN_LED_G, g ^ LED_COMMON_ANODE);
  digitalWrite(PIN_LED_B, b ^ LED_COMMON_ANODE);
}

void setLoad(bool on) {
  if (on && latched) { Serial.println(F("# 위험 래치 상태 - reset 후 부하 ON 가능")); return; }
  loadOn = on;
  digitalWrite(PIN_RELAY, on ? RELAY_ON_LEVEL : !RELAY_ON_LEVEL);
}

void addEvent(Level lv, const String& msg) {
  Event& e = evBuf[(evNextSeq - 1) % EVENT_BUFFER_SIZE];
  e.seq = evNextSeq++;
  e.ms = millis();
  e.level = lv;
  strncpy(e.msg, msg.c_str(), sizeof(e.msg) - 1);
  e.msg[sizeof(e.msg) - 1] = 0;
  if (plotMode == PLOT_OFF)   // 플로터 모드에서는 글자 줄이 그래프를 방해하므로 생략
    Serial.printf("EVENT,%lu,%s,%s\n", (unsigned long)e.ms, LEVEL_EN[lv], e.msg);
}

// ============================================================================
//  1. 측정 + 필터 (100 ms 마다)
// ============================================================================
void sampleSensors() {
  // (1) 전압: 분배된 전압 × 분배비 × 보정계수
  float vRaw = readMilliVolts(PIN_VBAT) / 1000.0f * (VDIV_R_TOP + VDIV_R_BOTTOM) / VDIV_R_BOTTOM * vCal;
  // (2) 전류: 션트 양단 전압 / 션트 저항 (I = V / R)
  // 수정됨: ESP32 ADC는 0V에서도 약 0.1V 안팎을 읽으므로, 릴레이가 꺼져 있는 동안 그 값을 0점으로 학습해 뺌
  static float iZeroMv = NAN;
  float shuntMv = readMilliVolts(PIN_ISHUNT);
  // 수정됨: 0점은 ADC 바닥값(0.2V 미만)일 때만 학습. 릴레이를 꺼도 전류가 흐르는 배선 실수(NC 연결 등)를 숨기지 않기 위함
  if (!loadOn && shuntMv < 200.0f) iZeroMv = isnan(iZeroMv) ? shuntMv : iZeroMv * 0.9f + shuntMv * 0.1f;
  float iRaw = (shuntMv - (isnan(iZeroMv) ? 0 : iZeroMv)) / SHUNT_OHM;   // mV / Ω = mA
  if (iRaw < 1.0f) iRaw = 0;                            // ADC 바닥 잡음 제거(데드밴드)  // 수정됨: 110Ω 션트 기준
  vRawLast = vRaw;
  iRawLast = iRaw;

  // (3) 이동평균 (Moving Average)
  maV[maIdx] = vRaw;
  maI[maIdx] = iRaw;
  maIdx = (maIdx + 1) % MA_WINDOW;
  if (maCount < MA_WINDOW) maCount++;
  float sv = 0, si = 0;
  for (int k = 0; k < maCount; k++) { sv += maV[k]; si += maI[k]; }
  vFilt = sv / maCount;
  iFilt = si / maCount;

  // (4) 시리얼 플로터 : 필터 전/후 비교 (10 Hz)
  if (plotMode == PLOT_V)
    Serial.printf("V_raw:%.3f,V_filter:%.3f,OV_warn:%.2f,UV_warn:%.2f\n", vRaw, vFilt, OV_WARNING, UV_WARNING);
  else if (plotMode == PLOT_I)
    Serial.printf("I_raw_mA:%.1f,I_filter_mA:%.1f,OC_caution:%.0f,OC_danger:%.0f\n", iRaw, iFilt, OC_CAUTION, OC_DANGER);
}

// DS18B20 비동기 읽기: 이번 주기에 결과를 읽고, 다음 변환을 시작 (변환시간 750ms < 1s)
void updateTemperature() {
  if (!dsFound) { tempOk = false; return; }
  if (dsConverting) {
    uint8_t d[9];
    ds.reset(); ds.select(dsAddr); ds.write(0xBE);       // Read Scratchpad
    for (int k = 0; k < 9; k++) d[k] = ds.read();
    if (OneWire::crc8(d, 8) == d[8]) {
      int16_t raw = (d[1] << 8) | d[0];
      float t = raw / 16.0f;
      tempOk = (t > -55 && t < 125 && t != 85.0f);       // 85.0 = 전원투입 기본값
      if (tempOk) tempC = t;
    } else {
      tempOk = false;
    }
  }
  ds.reset(); ds.select(dsAddr); ds.write(0x44);         // Convert T 시작
  dsConverting = true;
}

// ============================================================================
//  2. SOC 추정 : 리튬이온 OCV-SOC 테이블 선형 보간
//     (모의 셀은 부하 전류가 전압에 영향을 주지 않으므로 측정 전압 = OCV 로 봄)
// ============================================================================
const float OCV_V[]   = { 3.00, 3.30, 3.45, 3.60, 3.70, 3.75, 3.80, 3.90, 4.00, 4.10, 4.20 };
const float OCV_SOC[] = {    0,    5,   10,   20,   40,   50,   60,   70,   80,   90,  100 };
const int   OCV_N = sizeof(OCV_V) / sizeof(OCV_V[0]);

float socFromOcv(float v) {
  if (v <= OCV_V[0]) return 0;
  if (v >= OCV_V[OCV_N - 1]) return 100;
  for (int k = 1; k < OCV_N; k++) {
    if (v < OCV_V[k]) {
      float r = (v - OCV_V[k - 1]) / (OCV_V[k] - OCV_V[k - 1]);
      return OCV_SOC[k - 1] + r * (OCV_SOC[k] - OCV_SOC[k - 1]);
    }
  }
  return 100;
}

// ============================================================================
//  3. 상태 진단 (1 초 마다)
// ============================================================================
Level judge(float x, float c, float w, float d) {   // 값이 클수록 위험한 항목
  if (x >= d) return DANGER;
  if (x >= w) return WARNING;
  if (x >= c) return CAUTION;
  return NORMAL;
}
Level judgeLow(float x, float c, float w, float d) { // 값이 작을수록 위험한 항목
  if (x <= d) return DANGER;
  if (x <= w) return WARNING;
  if (x <= c) return CAUTION;
  return NORMAL;
}

void diagnose() {
  // (1) EMA로 한 번 더 평활화 → 1초 이력 저장 → 기울기(변화율) 계산
  vEma = isnan(vEma) ? vFilt : EMA_ALPHA * vFilt + (1 - EMA_ALPHA) * vEma;
  if (tempOk) tEma = isnan(tEma) ? tempC : EMA_ALPHA * tempC + (1 - EMA_ALPHA) * tEma;

  histV[histIdx] = vEma;
  histT[histIdx] = tEma;                                     // 센서 미검출이면 NAN
  int oldest = (histCount < SLOPE_WINDOW_S + 1) ? 0 : (histIdx + 1) % (SLOPE_WINDOW_S + 1);
  if (histCount < SLOPE_WINDOW_S + 1) histCount++;
  int span = histCount - 1;                                  // 경과 초
  if (span >= 5) {                                           // 최소 5초 이상 쌓인 뒤 계산
    dVdt = (histV[histIdx] - histV[oldest]) / span * 60.0f;  // V/min
    bool tValid = !isnan(histT[histIdx]) && !isnan(histT[oldest]);
    dTdt = tValid ? (histT[histIdx] - histT[oldest]) / span * 60.0f : 0;  // °C/min
  }
  histIdx = (histIdx + 1) % (SLOPE_WINDOW_S + 1);

  // (2) SOC + 부하 전류 적산(쿨롱 카운팅)
  socPct = 0;   // 수정됨: 배터리가 없으므로 SOC는 계산하지 않음 (대시보드에 0으로 표시)
  mAhOut += iFilt * (REPORT_PERIOD_MS / 3600000.0f);

  // (3) 항목별 4단계 판정
  Level lv = NORMAL;
  reasonStr = "";
  auto check = [&](Level l, const char* name) {
    if (l > NORMAL) { if (reasonStr.length()) reasonStr += ", "; reasonStr += name; }
    lv = maxLv(lv, l);
  };
  check(judge(vFilt, OV_CAUTION, OV_WARNING, OV_DANGER), "OverVolt");
  check(judgeLow(vFilt, UV_CAUTION, UV_WARNING, UV_DANGER), "UnderVolt");
  check(judge(iFilt, OC_CAUTION, OC_WARNING, OC_DANGER), "OverCurrent");
  if (tempOk) {
    check(judge(tempC, OT_CAUTION, OT_WARNING, OT_DANGER), "OverTemp");
    check(judge(dTdt, DTDT_CAUTION, DTDT_WARNING, DTDT_DANGER), "TempRise");
  } else {
    check(WARNING, "TempSensorFail");                        // 센서 고장도 이상으로 처리
  }

  // (4) 열폭주 예측: 지금 기울기로 위험온도까지 몇 분 남았나? (1차 미분 외삽)
  minsToDanger = -1;
  if (tempOk && dTdt > 0.2f && tempC < OT_DANGER) {
    minsToDanger = (OT_DANGER - tempC) / dTdt;
    if (minsToDanger < PREDICT_WARN_MIN) check(WARNING, "RunawayPredict");
  }

  // (5) 위험도 지수 (0~100) = Σ 가중치 × 정규화 값
  float nV  = max((vFilt - V_NOMINAL) / (OV_DANGER - V_NOMINAL), (V_NOMINAL - vFilt) / (V_NOMINAL - UV_DANGER));  // 수정됨: 5V 기준
  float nT  = tempOk ? (tempC - 25.0f) / (OT_DANGER - 25.0f) : 0.5f;
  float nDV = fabsf(dVdt) / 0.2f;                           // 0.2 V/min 를 최대로 봄
  float nDT = dTdt / DTDT_DANGER;
  riskIdx = 100.0f * (W_VOLT * clamp01(nV) + W_TEMP * clamp01(nT) +
                      W_DVDT * clamp01(nDV) + W_DTDT * clamp01(nDT));
  check(judge(riskIdx, RISK_CAUTION, RISK_WARNING, RISK_DANGER), "RiskIndex");

  if (reasonStr.length() == 0) reasonStr = "OK";
  level = lv;

  // (6) 보호 동작: 위험 → 부하 차단 + 래치
  if (level == DANGER && !latched) {
    latched = true;
    loadOn = false;
    digitalWrite(PIN_RELAY, !RELAY_ON_LEVEL);
  }
  // 단계가 바뀌면 이벤트 기록
  if (level != prevLevel) {
    addEvent(level, String(LEVEL_EN[prevLevel]) + "-> " + LEVEL_EN[level] + " (" + reasonStr + ")");
    prevLevel = level;
  }
}

void tryReset() {
  if (level == DANGER) { Serial.println(F("# 아직 위험 조건이 남아 있어 리셋 불가")); return; }
  latched = false;
  addEvent(level, "Manual reset");
}

// ============================================================================
//  4. 기록(FIFO) / 출력
// ============================================================================
void pushRecord() {
  Record& r = logBuf[(logNextSeq - 1) % LOG_BUFFER_SIZE];   // 가득 차면 가장 오래된 것부터 덮어씀
  r.seq = logNextSeq++;
  r.ms = millis();
  r.v = vFilt; r.i = iFilt; r.t = tempOk ? tempC : NAN;
  r.soc = socPct; r.risk = riskIdx;
  r.level = level; r.load = loadOn;
}

void printSerial() {
  if (plotMode == PLOT_OFF) {
    // DATA,seq,ms,V,mA,degC,SOC,dVdt,dTdt,risk,level,load
    Serial.printf("DATA,%lu,%lu,%.3f,%.1f,%.2f,%.1f,%.4f,%.2f,%.1f,%d,%d\n",
                  (unsigned long)(logNextSeq - 1), (unsigned long)millis(), vFilt, iFilt,
                  tempOk ? tempC : NAN, socPct, dVdt, dTdt, riskIdx, level, loadOn);
  } else if (plotMode == PLOT_T && tempOk) {
    Serial.printf("Temp_C:%.2f,OT_caution:%.0f,OT_warning:%.0f,OT_danger:%.0f\n",
                  tempC, OT_CAUTION, OT_WARNING, OT_DANGER);
  }
}

// 수정됨: LCD 대신 TFT 대시보드를 1초마다 갱신
void updateTft() {
  ui::update(vFilt, iFilt, tempOk, tempC, dTdt, riskIdx, minsToDanger,
             (int)level, latched, loadOn, reasonStr);
}

// ============================================================================
//  5. 경보 출력 (LED / 부저) - 비차단(millis) 방식
// ============================================================================
// 부저: 주파수가 바뀔 때만 tone()/noTone() 호출 (매 loop 호출하면 내부 큐가 넘침)
void buzzer(uint16_t freq) {
  static uint16_t cur = 0xFFFF;
  if (freq == cur) return;
  cur = freq;
  if (freq) tone(PIN_BUZZER, freq); else noTone(PIN_BUZZER);
}

void updateAlarm() {
  uint32_t now = millis();
  bool blink = (now / 250) % 2;
  if (latched && level != DANGER) {           // 위험은 해소됐지만 리셋 전(래치) → 파랑 깜빡
    setRgb(0, 0, blink); buzzer(0); return;
  }
  switch (level) {
    case NORMAL:  setRgb(0, 1, 0); buzzer(0); break;                     // 초록
    case CAUTION: setRgb(1, 1, 0); buzzer(0); break;                     // 노랑(빨+초)
    case WARNING:                                                        // 빨강 깜빡 + 2초마다 짧은 삑
      setRgb(blink, 0, 0);
      buzzer(now % 2000 < 120 ? 2000 : 0);
      break;
    case DANGER:                                                         // 빨강 + 단속 경보음
      setRgb(1, 0, 0);
      buzzer(blink ? 2500 : 0);
      break;
  }
}

// ============================================================================
//  6. 명령 처리 (시리얼 / 웹 공통)
// ============================================================================
String doCommand(String c) {
  c.trim();
  c.toLowerCase();
  if (c == "on")    { setLoad(true);  return latched ? "latched" : "load on"; }
  if (c == "off")   { setLoad(false); return "load off"; }
  if (c == "reset") { tryReset();     return latched ? "still danger" : "reset ok"; }
  if (c == "zero")  { mAhOut = 0; return "mAh cleared"; }
  if (c == "plot")  { plotMode = (PlotMode)((plotMode + 1) % 4); return String("plot ") + PLOT_NAME[plotMode]; }
  if (c == "plot v") { plotMode = PLOT_V;   return "plot voltage"; }
  if (c == "plot i") { plotMode = PLOT_I;   return "plot current"; }
  if (c == "plot t") { plotMode = PLOT_T;   return "plot temperature"; }
  if (c == "plot off") { plotMode = PLOT_OFF; return "plot off(CSV)"; }
  if (c.startsWith("cal ")) {        // 예: cal 3.912  (멀티미터로 잰 가변저항 와이퍼 전압)
    float actual = c.substring(4).toFloat();
    if (actual > 2.0f && actual < 5.5f && vFilt > 1.0f) {
      vCal = vCal * actual / vFilt;
      prefs.putFloat("vcal", vCal);
      maCount = 0;
      return "vCal=" + String(vCal, 4);
    }
    return "cal error";
  }
  if (c == "help" || c == "?") {
    return "on | off | reset | zero | cal <V> | plot [v|i|t|off] | help";
  }
  return "unknown command";
}

void reply(const String& s) {        // 명령 응답 (플로터 모드에서는 그래프를 깨지 않도록 생략)
  if (plotMode == PLOT_OFF || s.startsWith("plot")) Serial.println("# " + s);
}

void handleSerial() {
  static String line;
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (line.length()) reply(doCommand(line));
      line = "";
    } else if (line.length() < 40) {
      line += ch;
    }
  }
}

// 버튼: 짧게 = 부하 ON/OFF (래치 중이면 리셋),  길게(1.5s↑) = 시리얼 플로터 모드 전환
void handleButton() {
  static bool last = HIGH;
  static uint32_t tDown = 0, tChange = 0;
  bool now = digitalRead(PIN_BUTTON);
  if (now != last && millis() - tChange > 30) {    // 30ms 디바운스
    tChange = millis();
    if (now == LOW) tDown = millis();
    else {
      uint32_t held = millis() - tDown;
      if (held >= 1500) reply(doCommand("plot"));
      else if (latched) reply(doCommand("reset"));
      else reply(doCommand(loadOn ? "off" : "on"));
    }
    last = now;
  }
}

// ============================================================================
//  7. 웹 서버
// ============================================================================
void appendRecordJson(String& s, const Record& r) {
  char b[160];
  snprintf(b, sizeof(b), "[%lu,%lu,%.3f,%.1f,%s,%.1f,%.1f,%u,%u]",
           (unsigned long)r.seq, (unsigned long)r.ms, r.v, r.i,
           isnan(r.t) ? "null" : String(r.t, 2).c_str(), r.soc, r.risk, r.level, r.load);
  s += b;
}

// GET /api/data?since=N&ev=M  → 현재 상태 + seq>N 인 기록 + seq>M 인 이벤트
void handleData() {
  uint32_t since = server.hasArg("since") ? strtoul(server.arg("since").c_str(), nullptr, 10) : 0;
  uint32_t evSince = server.hasArg("ev") ? strtoul(server.arg("ev").c_str(), nullptr, 10) : 0;
  uint32_t last = logNextSeq - 1;
  uint32_t first = (last > LOG_BUFFER_SIZE) ? last - LOG_BUFFER_SIZE + 1 : 1;  // 버퍼에 남아있는 가장 오래된 seq
  if (since + 1 > first) first = since + 1;
  if (last >= first && last - first + 1 > 120) last = first + 119;            // 한 번에 최대 120건

  String s;
  s.reserve(12000);
  char b[400];
  snprintf(b, sizeof(b),
           "{\"now\":{\"v\":%.3f,\"i\":%.1f,\"t\":%s,\"soc\":%.1f,\"mah\":%.2f,\"dvdt\":%.4f,"
           "\"dtdt\":%.2f,\"risk\":%.1f,\"pred\":%.1f,\"level\":%d,\"load\":%d,\"latched\":%d,"
           "\"reason\":\"%s\",\"uptime\":%lu,\"head\":%lu},\"rec\":[",
           vFilt, iFilt, tempOk ? String(tempC, 2).c_str() : "null", socPct, mAhOut, dVdt, dTdt,
           riskIdx, minsToDanger, level, loadOn, latched, reasonStr.c_str(),
           (unsigned long)millis(), (unsigned long)(logNextSeq - 1));
  s += b;
  bool firstItem = true;
  for (uint32_t q = first; q <= last && q >= 1 && q < logNextSeq; q++) {
    if (!firstItem) s += ',';
    appendRecordJson(s, logBuf[(q - 1) % LOG_BUFFER_SIZE]);
    firstItem = false;
  }
  s += "],\"ev\":[";
  firstItem = true;
  uint32_t evFirst = (evNextSeq - 1 > EVENT_BUFFER_SIZE) ? evNextSeq - EVENT_BUFFER_SIZE : 1;
  if (evSince + 1 > evFirst) evFirst = evSince + 1;
  for (uint32_t q = evFirst; q < evNextSeq; q++) {
    const Event& e = evBuf[(q - 1) % EVENT_BUFFER_SIZE];
    snprintf(b, sizeof(b), "%s[%lu,%lu,%u,\"%s\"]", firstItem ? "" : ",",
             (unsigned long)e.seq, (unsigned long)e.ms, e.level, e.msg);
    s += b;
    firstItem = false;
  }
  s += "]}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", s);
}

void setupWeb() {
  uint64_t mac = ESP.getEfuseMac();
  char id[5];
  snprintf(id, sizeof(id), "%04X", (uint16_t)(mac >> 32));
  apSsid = String(WIFI_SSID_PREFIX) + id;
  WiFi.mode(WIFI_AP);
  WiFi.softAP(apSsid.c_str(), WIFI_PASSWORD);

  server.on("/", []() { server.send_P(200, "text/html; charset=utf-8", DASHBOARD_HTML); });
  server.on("/api/data", handleData);
  server.on("/api/cmd", []() {
    String r = doCommand(server.arg("c"));
    server.send(200, "text/plain; charset=utf-8", r);
  });
  server.begin();
}

// ============================================================================
//  setup / loop
// ============================================================================
void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println(F("# ESP32 BMS firmware " FW_VERSION));   // 수정됨

  pinMode(PIN_RELAY, OUTPUT);
  digitalWrite(PIN_RELAY, !RELAY_ON_LEVEL);   // 부팅 시 부하 OFF (안전)
  pinMode(PIN_LED_R, OUTPUT);
  pinMode(PIN_LED_G, OUTPUT);
  pinMode(PIN_LED_B, OUTPUT);
  pinMode(PIN_BUZZER, OUTPUT);
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  analogReadResolution(12);                   // 0~4095, 감쇠 기본값 11dB(약 0~3.1V)
  // 수정됨: 110Ω 션트는 최대 약 2.9V가 걸리므로 기본 11dB 감쇠(0~3.1V)를 그대로 사용
  setRgb(0, 0, 1);

  ui::begin();                                // 수정됨: TFT 시작

  prefs.begin("bms", false);
  vCal = prefs.getFloat("vcal", 1.0f);

  // DS18B20 찾기
  ds.reset_search();
  dsFound = ds.search(dsAddr) && OneWire::crc8(dsAddr, 7) == dsAddr[7] && dsAddr[0] == 0x28;
  if (dsFound) updateTemperature();           // 첫 변환 시작

  setupWeb();
  ui::bootScreen(apSsid, WIFI_PASSWORD);     // 수정됨: 접속 정보를 TFT에 표시

  Serial.println(F("# ESP32 BMS (mock cell) v1.0 - 'help' 입력 시 명령 목록"));
  Serial.printf("# WiFi AP: %s / %s  ->  http://192.168.4.1\n", apSsid.c_str(), WIFI_PASSWORD);
  Serial.printf("# DS18B20 %s, vCal=%.4f\n", dsFound ? "found" : "NOT FOUND", vCal);
  Serial.println(F("# DATA,seq,ms,V,mA,degC,SOC,dVdt(V/min),dTdt(C/min),risk,level,load"));
  addEvent(NORMAL, "Boot");
  delay(3000);                                // 접속 정보를 3초간 표시
  tSample = tReport = millis();
}

void loop() {
  uint32_t now = millis();
  if (now - tSample >= SAMPLE_PERIOD_MS) {     // 10 Hz 측정
    tSample += SAMPLE_PERIOD_MS;
    sampleSensors();
  }
  if (now - tReport >= REPORT_PERIOD_MS) {     // 1 Hz 진단·기록·표시
    tReport += REPORT_PERIOD_MS;
    updateTemperature();
    diagnose();
    pushRecord();
    printSerial();
    updateTft();                               // 수정됨
  }
  updateAlarm();
  handleButton();
  handleSerial();
  server.handleClient();
}
