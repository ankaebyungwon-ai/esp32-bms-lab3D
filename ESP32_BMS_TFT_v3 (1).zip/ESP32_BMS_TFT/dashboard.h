/*
 * dashboard.h  -  ESP32 내장 웹 대시보드 (모의 셀 버전) (HTML + JavaScript)
 * 외부 인터넷 없이(AP 모드) 동작하도록 그래프도 <canvas>로 직접 그립니다.
 *
 * 동작 원리
 *  - 브라우저가 1초마다 /api/data?since=<마지막으로 받은 seq> 를 요청
 *  - ESP32는 seq 이후의 기록을 FIFO 버퍼에서 꺼내 한꺼번에 보내줌
 *  - Wi-Fi가 끊겼다 다시 연결되면, 끊긴 동안 쌓인 기록이 순서대로 전송되어 그래프 공백이 메워짐
 */
#pragma once

const char DASHBOARD_HTML[] PROGMEM = R"rawliteral(
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ESP32 BMS 대시보드</title>
<style>
  :root { --bg:#f4f6f9; --card:#fff; --ink:#1d2433; --sub:#667085; --line:#e3e7ee;
          --ok:#1a9e55; --caution:#d99a00; --warn:#e8590c; --danger:#d0262d; --accent:#2563eb; }
  * { box-sizing:border-box; }
  body { margin:0; font-family:-apple-system,"Malgun Gothic",sans-serif; background:var(--bg); color:var(--ink); }
  header { display:flex; justify-content:space-between; align-items:center; padding:12px 16px;
           background:#1d2433; color:#fff; }
  header h1 { font-size:17px; margin:0; }
  #conn { font-size:13px; padding:3px 10px; border-radius:12px; background:#1a9e55; }
  main { max-width:1100px; margin:0 auto; padding:12px 16px 40px; }
  #banner { border-radius:10px; padding:14px 16px; color:#fff; font-weight:700; font-size:18px;
            display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px; }
  #banner small { font-weight:400; font-size:13px; opacity:.9; }
  .grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; margin:12px 0; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:10px; padding:10px 12px; }
  .card .k { font-size:12px; color:var(--sub); }
  .card .v { font-size:24px; font-weight:700; margin-top:2px; font-variant-numeric:tabular-nums; }
  .card .u { font-size:13px; color:var(--sub); font-weight:400; }
  .bar { height:6px; background:var(--line); border-radius:3px; margin-top:6px; overflow:hidden; }
  .bar i { display:block; height:100%; background:var(--accent); }
  .btns { display:flex; flex-wrap:wrap; gap:8px; margin:6px 0 12px; }
  button { border:1px solid var(--line); background:#fff; border-radius:8px; padding:8px 14px;
           font-size:14px; cursor:pointer; }
  button.primary { background:var(--accent); color:#fff; border-color:var(--accent); }
  canvas { width:100%; height:170px; display:block; }
  h2 { font-size:15px; margin:14px 0 6px; }
  #log { max-height:220px; overflow:auto; font-size:13px; }
  #log div { padding:4px 0; border-bottom:1px solid var(--line); }
  .lv0{color:var(--ok)} .lv1{color:var(--caution)} .lv2{color:var(--warn)} .lv3{color:var(--danger)}
  #modal { position:fixed; inset:0; background:rgba(0,0,0,.45); display:none; align-items:center;
           justify-content:center; padding:16px; }
  #modal .box { background:#fff; border-radius:12px; padding:20px; max-width:420px; width:100%;
                border-top:8px solid var(--danger); }
  #modal h3 { margin:0 0 8px; }
  .muted { color:var(--sub); font-size:12px; }
</style>
</head>
<body>
<header><h1>ESP32 BMS 실시간 관제 (모의 셀)</h1><span id="conn">연결 중…</span></header>
<main>
  <div id="banner" style="background:#667085"><span id="lvText">-</span><small id="reason"></small></div>

  <div class="grid">
    <div class="card"><div class="k">모의 셀 전압</div><div class="v"><span id="v">-</span> <span class="u">V</span></div></div>
    <div class="card"><div class="k">부하 전류</div><div class="v"><span id="i">-</span> <span class="u">mA</span></div></div>
    <div class="card"><div class="k">온도</div><div class="v"><span id="t">-</span> <span class="u">°C</span></div></div>
    <div class="card"><div class="k">SOC (충전상태)</div><div class="v"><span id="soc">-</span> <span class="u">%</span></div>
      <div class="bar"><i id="socBar" style="width:0"></i></div></div>
    <div class="card"><div class="k">위험도 지수</div><div class="v"><span id="risk">-</span> <span class="u">/100</span></div>
      <div class="bar"><i id="riskBar" style="width:0;background:var(--danger)"></i></div></div>
    <div class="card"><div class="k">온도 변화율 dT/dt</div><div class="v"><span id="dtdt">-</span> <span class="u">°C/min</span></div>
      <div class="muted" id="pred"></div></div>
    <div class="card"><div class="k">전압 변화율 dV/dt</div><div class="v"><span id="dvdt">-</span> <span class="u">V/min</span></div></div>
    <div class="card"><div class="k">누적 용량 / 부하</div><div class="v"><span id="mah">-</span> <span class="u">mAh</span></div>
      <div class="muted" id="load"></div></div>
  </div>

  <div class="btns">
    <button class="primary" onclick="cmd('on')">부하 ON (방전 시작)</button>
    <button onclick="cmd('off')">부하 OFF</button>
    <button onclick="cmd('reset')">경보 리셋</button>
    <button onclick="cmd('zero')">mAh 초기화</button>
    <button onclick="downloadCsv()">CSV 저장</button>
  </div>

  <h2>전압 [V]</h2><div class="card"><canvas id="cV"></canvas></div>
  <h2>전류 [mA]</h2><div class="card"><canvas id="cI"></canvas></div>
  <h2>온도 [°C]</h2><div class="card"><canvas id="cT"></canvas></div>

  <h2>이상 발생 이력</h2>
  <div class="card" id="log"></div>
  <p class="muted" id="stat"></p>
</main>

<div id="modal"><div class="box">
  <h3 id="mTitle">경고</h3><p id="mMsg"></p>
  <button class="primary" onclick="document.getElementById('modal').style.display='none'">확인</button>
</div></div>

<script>
const LV = ['정상', '주의', '경고', '위험'];
const LVC = ['#1a9e55', '#d99a00', '#e8590c', '#d0262d'];
let lastSeq = 0, lastEv = 0, rows = [], online = false, offlineSince = 0, recovered = 0, catchingUp = false;
const $ = id => document.getElementById(id);

async function cmd(c) {
  try { const r = await fetch('/api/cmd?c=' + encodeURIComponent(c)); toast(await r.text()); }
  catch (e) { toast('명령 전송 실패'); }
}
function toast(s) { $('stat').textContent = '명령 결과: ' + s; }
function fmt(x, d) { return (x === null || x === undefined || isNaN(x)) ? '-' : Number(x).toFixed(d); }
function msToTime(ms) { const s = Math.floor(ms / 1000); return Math.floor(s / 60) + '분 ' + (s % 60) + '초'; }

async function poll() {
  let next = 1000;
  try {
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 3000);  // 3초 응답 없으면 끊김 처리
    const r = await fetch('/api/data?since=' + lastSeq + '&ev=' + lastEv, { cache: 'no-store', signal: ctl.signal });
    clearTimeout(to);
    const j = await r.json();
    if (j.now.head < lastSeq) { lastSeq = 0; lastEv = 0; rows = []; }   // ESP32 재부팅 감지
    if (!online && offlineSince) {                                      // 끊겼다가 방금 재접속
      addLog(1, '재접속 (끊김 ' + Math.round((Date.now() - offlineSince) / 1000) + '초)', j.now.uptime);
      catchingUp = true; recovered = 0;
    }
    online = true; offlineSince = 0;
    if (catchingUp) {
      recovered += j.rec.length;
      if (j.rec.length < 120) { addLog(0, '끊긴 동안의 미전송 기록 ' + recovered + '건 일괄 수신(FIFO)', j.now.uptime); catchingUp = false; }
    }
    if (j.rec.length) {
      if (lastSeq && j.rec[0][0] > lastSeq + 1) addLog(2, '버퍼 초과로 ' + (j.rec[0][0] - lastSeq - 1) + '건 유실', j.now.uptime);
      for (const a of j.rec) rows.push({ seq:a[0], ms:a[1], v:a[2], i:a[3], t:a[4], soc:a[5], risk:a[6], lv:a[7], load:a[8] });
      lastSeq = j.rec[j.rec.length - 1][0];
      if (rows.length > 3600) rows.splice(0, rows.length - 3600);
      if (j.rec.length >= 120) next = 50;                    // 밀린 데이터가 더 있으면 바로 다시 요청
    }
    const firstLoad = (lastEv === 0);                         // 처음 열었을 때 과거 이력은 팝업하지 않음
    for (const e of j.ev) {
      addLog(e[2], e[3], e[1]);
      if (e[2] >= 2 && !firstLoad) popup(e[2], e[3]);
      lastEv = e[0];
    }
    show(j.now);
    $('conn').textContent = '연결됨';
    $('conn').style.background = '#1a9e55';
  } catch (e) {
    if (online || !offlineSince) offlineSince = Date.now();
    online = false;
    $('conn').textContent = '연결 끊김 - 재접속 시도 중 (' + Math.round((Date.now() - offlineSince) / 1000) + 's)';
    $('conn').style.background = '#d0262d';
  }
  draw();
  setTimeout(poll, next);
}

function show(n) {
  $('v').textContent = fmt(n.v, 3);
  $('i').textContent = fmt(n.i, 1);
  $('t').textContent = n.t === null ? 'ERR' : fmt(n.t, 1);
  $('soc').textContent = fmt(n.soc, 0);
  $('socBar').style.width = n.soc + '%';
  $('risk').textContent = fmt(n.risk, 0);
  $('riskBar').style.width = Math.min(100, n.risk) + '%';
  $('dtdt').textContent = (n.dtdt >= 0 ? '+' : '') + fmt(n.dtdt, 2);
  $('dvdt').textContent = (n.dvdt >= 0 ? '+' : '') + fmt(n.dvdt, 3);
  $('pred').textContent = n.pred > 0 ? '위험온도 도달 예상: ' + fmt(n.pred, 1) + '분' : '';
  $('mah').textContent = fmt(n.mah, 1);
  $('load').textContent = (n.latched ? '차단됨(TRIP) - 리셋 필요' : (n.load ? '부하 ON' : '부하 OFF'));
  $('lvText').textContent = '상태: ' + LV[n.level] + (n.latched ? ' · 부하 차단' : '');
  $('reason').textContent = '판정 사유: ' + n.reason + ' · 가동 ' + msToTime(n.uptime);
  $('banner').style.background = LVC[n.level];
  $('stat').textContent = '수신 기록 ' + rows.length + '건 · 마지막 seq ' + lastSeq;
}

function addLog(lv, msg, ms) {
  const d = document.createElement('div');
  d.innerHTML = '<b class="lv' + lv + '">[' + LV[lv] + ']</b> ' + msg + ' <span class="muted">(' + msToTime(ms) + ')</span>';
  $('log').prepend(d);
}

function popup(lv, msg) {
  $('mTitle').textContent = LV[lv] + ' 발생!';
  $('mTitle').style.color = LVC[lv];
  $('mMsg').textContent = msg;
  $('modal').style.display = 'flex';
  if (navigator.vibrate) navigator.vibrate([300, 100, 300]);  // 스마트폰 진동 알림
}

function chart(id, key, color) {
  const c = $(id), w = c.clientWidth, h = c.clientHeight, dpr = window.devicePixelRatio || 1;
  c.width = w * dpr; c.height = h * dpr;
  const g = c.getContext('2d'); g.scale(dpr, dpr); g.clearRect(0, 0, w, h);
  const pts = rows.slice(-300).filter(r => r[key] !== null);
  if (pts.length < 2) { g.fillStyle = '#999'; g.fillText('데이터 수집 중…', 10, 20); return; }
  let lo = Math.min(...pts.map(p => p[key])), hi = Math.max(...pts.map(p => p[key]));
  if (hi - lo < 1e-3) { hi += 0.5; lo -= 0.5; }
  const pad = (hi - lo) * 0.1; lo -= pad; hi += pad;
  const L = 48, R = 8, T = 8, B = 20;
  const x0 = pts[0].ms, x1 = pts[pts.length - 1].ms;
  const X = ms => L + (ms - x0) / Math.max(1, x1 - x0) * (w - L - R);
  const Y = v => T + (hi - v) / (hi - lo) * (h - T - B);
  g.strokeStyle = '#e3e7ee'; g.fillStyle = '#667085'; g.font = '11px sans-serif'; g.lineWidth = 1;
  for (let k = 0; k <= 4; k++) {
    const v = lo + (hi - lo) * k / 4, y = Y(v);
    g.beginPath(); g.moveTo(L, y); g.lineTo(w - R, y); g.stroke();
    g.fillText(v.toFixed(key === 'v' ? 2 : 1), 4, y + 4);
  }
  g.fillText('-' + Math.round((x1 - x0) / 1000) + 's', L, h - 4);
  g.fillText('now', w - R - 22, h - 4);
  g.strokeStyle = color; g.lineWidth = 2; g.beginPath();
  pts.forEach((p, k) => {
    const gap = k > 0 && p.seq !== pts[k - 1].seq + 1;      // 유실 구간은 선을 끊음
    (k === 0 || gap) ? g.moveTo(X(p.ms), Y(p[key])) : g.lineTo(X(p.ms), Y(p[key]));
  });
  g.stroke();
  g.fillStyle = '#d0262d';                                   // 경고·위험 시점은 빨간 점으로 표시
  pts.forEach(p => { if (p.lv >= 2) { g.beginPath(); g.arc(X(p.ms), Y(p[key]), 2.5, 0, 7); g.fill(); } });
}
function draw() { chart('cV', 'v', '#2563eb'); chart('cI', 'i', '#7c3aed'); chart('cT', 't', '#e8590c'); }

function downloadCsv() {
  let s = 'seq,uptime_ms,voltage_V,current_mA,temp_C,soc_pct,risk,level,load\n';
  for (const r of rows) s += [r.seq, r.ms, r.v, r.i, r.t, r.soc, r.risk, r.lv, r.load].join(',') + '\n';
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([s], { type: 'text/csv' }));
  a.download = 'bms_log.csv'; a.click();
}
window.addEventListener('resize', draw);
poll();
</script>
</body>
</html>
)rawliteral";
